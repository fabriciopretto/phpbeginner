<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    $conexao = pg_connect("host=localhost port=5432 dbname=espaco40 user=postgres password=postgres");

    $user = 'user2';
    $senha = 'senha2';
    $result = pg_query($conexao, "select * from usuario where nome = '$user' and senha = '$senha'");

    $sucesso = pg_fetch_result($result, 1);

    print 'Resultado: ' . $sucesso;

    ?>
</body>

</html>