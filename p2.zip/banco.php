<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Acessando banco</h1>

    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    $conexao = pg_connect("host=localhost port=5432 dbname=espaco40 user=postgres password=postgres");

    if ($conexao) {
        print 'Sucesso na conexão';
    } else {
        print 'Erro ao conectar no banco.';
    }
    print '<br>';

    $result = pg_query($conexao, "select * from teste");
    // var_dump(pg_fetch_all($result));

    while($val = pg_fetch_array($result)) {
        print $val[0] . ' ' . $val[1] . '<br>';
    }

    ?>
</body>

</html>