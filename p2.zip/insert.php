<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    $conexao = pg_connect("host=localhost port=5432 dbname=espaco40 user=postgres password=postgres");

    if ($conexao) {
        print 'Sucesso na conexão';
    } else {
        print 'Erro ao conectar no banco.';
    }
    print '<br>';

    $item = $_GET['item'];
    $result = pg_query($conexao, "insert into teste values (default, '$item')");

    if ($result) {
        print 'Registro salvo com sucesso.';
    } else {
        print 'Erro tentar salvar registro.';
    }

    ?>

</body>

</html>